<?php
include_once "inc/connection.php";

  $packID = $_GET["packID"];

 // sql to delete a record
 $sql = "DELETE FROM usertable WHERE id=$packID";

if (mysqli_query($conn, $sql)) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . mysqli_error($conn);
}



?>