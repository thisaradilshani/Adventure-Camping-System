<?php 
if (!isset($_SESSION)) {
    session_start();
  }
  
  if (!isset($_SESSION['userID'])) {
      header('Location: login.php');
  }
  include_once "inc/connection.php";

  $today = date('Y-m-d');
?>

<!doctype html>
<html lang="en">

<head>
    <title>Dashboard | Olympia Adventure Camp</title>
    <?php include "inc/head.php"; ?>

</head>

<body>
    <!-- WRAPPER -->
    <div id="wrapper">
        <!-- NAVBAR -->
        <?php include_once "inc/navbar.php" ?>
        <!-- END NAVBAR -->

        <!-- LEFT SIDEBAR -->
        <?php include_once "inc/sidebar.php" ?>
        <!-- END LEFT SIDEBAR -->

        <!-- MAIN -->
        <div class="main">
            <!-- MAIN CONTENT -->
            <div class="main-content">
                <div class="container-fluid">
                    <!-- INPUTS -->
                    <div class="panel">
                        <div class="panel-heading">
                            <h3 class="panel-title">Create New Booking</h3>
                        </div>
                        <div class="panel-body">
                            <div class="alert alert-success" id="success" style="display: none;">
                                <strong>Success!</strong> New Package Created.
                            </div>
                            <div class="alert alert-danger" id="error" style="display: none;">
                                <strong>Danger!</strong> Indicates a dangerous or potentially negative action.
                            </div>
                            <div class="row justify-content-md-center">
                                <div class="col-md-8 col-md-offset-2">
                                    <form name="bookingFrm" id="bookingFrm">
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Check Arrival Date</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="date" id="input-group" class="form-control input-box form-rounded" name="check_in_date" data-date-format="mm-dd-yyyy" placeholder="" value="" min="<?php echo $today; ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Check Departure Date</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="date" id="input-group" class="form-control input-box form-rounded" name="check_out_date" data-date-format="mm-dd-yyyy" placeholder="" min="<?php echo $today; ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">First Name</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="text" id="input-group" class="form-control input-box form-rounded" name="First_name" placeholder="first name" required>
                                            </div>
                                        </div>
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Last Name</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="text" id="input-group" class="form-control input-box form-rounded" name="Last_name" placeholder="last name" required>
                                            </div>
                                        </div>
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Contact Number</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="tel" id="input-group" class="form-control input-box form-rounded" name="contact_number" placeholder="Ex:0094123456789" pattern="[0]{1}[0-9]{12}" required>
                                            </div>
                                        </div>
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Email</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="email" id="input-group" class="form-control input-box form-rounded" name="email" placeholder="email" required>
                                            </div>
                                        </div>
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Package Type</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control" name="packid" id="packid">
                                        <?php
                                        $sql_select = "SELECT * FROM `packages` ORDER BY `pack_name` ASC";
                                        $result_select = mysqli_query($conn, $sql_select);

                                        if (mysqli_num_rows($result_select) > 0) {
                                            // output data of each row
                                            while ($row_select = mysqli_fetch_assoc($result_select)) {
                                        ?>
                                                <option value="<?php echo $row_select["id"]; ?>"><?php echo $row_select["pack_name"]; ?></option>

                                        <?php
                                            }
                                        } else {
                                            echo "0 results";
                                        }
                                        ?>

                                    </select>
                                            </div>
                                        </div>
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Additional Activities</label>
                                            </div>
                                            <div class="col-md-8">
                                                <select id="activitySelect" name="activitySelect[]" class="js-states form-control"  multiple="multiple" >
                                                    <?php
                                                    $sql_activity = "SELECT * FROM `camp_activity` WHERE `ac_status` = 'active'";
                                                    $resut_activity = mysqli_query($conn, $sql_activity);
                                                    
                                                    if (mysqli_num_rows($resut_activity) > 0) {
                                                      // output data of each row
                                                      while($row_activity = mysqli_fetch_assoc($resut_activity)) {
                                                        
                                                ?>
                                                    <option value="<?php echo $row_activity["aid"]?>"><?php echo $row_activity["ac_name"]?></option>
                                                    <?php 
                                                          }
                                                        } else {
                                                          echo "0 results";
                                                        }
                                                         ?>
                                                </select>
                                                <script>                                         
                                                $("#activitySelect").select2({
                                                    placeholder: "Select Activities",
                                                    allowClear: true
                                                });
                                                </script>
                                            </div>
                                        </div>
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Rooms</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control w-100 input-box form-rounded" name="Room_type" id="Room_type">
                                            <?php
                                            $sql_rooms = "SELECT * FROM rooms";
                                            $result_rooms = mysqli_query($conn, $sql_rooms);

                                            if (mysqli_num_rows($result_rooms) > 0) {
                                                // output data of each row
                                                while ($row_rooms = mysqli_fetch_assoc($result_rooms)) {
                                            ?>
                                                    <option value="<?php echo $row_rooms["id"] ?>"><?php echo $row_rooms["Room_type"] ?></option>

                                            <?php

                                                }
                                            }
                                            ?>
                                        </select>
                                     
                                            </div>
                                        </div>      
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Tents</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control w-100 input-box form-rounded" name="Tent_type" id="Tent_type">
                                            <?php
                                            $sql_tent = "SELECT * FROM tent";
                                            $result_tent = mysqli_query($conn, $sql_tent);

                                            if (mysqli_num_rows($result_tent) > 0) {
                                                // output data of each row
                                                while ($row_tent = mysqli_fetch_assoc($result_tent)) {
                                            ?>
                                                    <option value="<?php echo $row_tent["id"] ?>"><?php echo $row_tent["Tent_type"] ?></option>

                                            <?php

                                                }
                                            }
                                            ?>
                                        </select>
                                            </div>
                                        </div>       
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Meals</label>
                                            </div>
                                            <div class="col-md-8">
                                            <select class="form-control w-100 input-box form-rounded" name="Meals_type" id="Meals_type">
                                            <?php
                                            $sql_meal = "SELECT * FROM meals";
                                            $result_meal = mysqli_query($conn, $sql_meal);

                                            if (mysqli_num_rows($result_meal) > 0) {
                                                // output data of each row
                                                while ($row_meal = mysqli_fetch_assoc($result_meal)) {
                                            ?>
                                                    <option value="<?php echo $row_meal["id"] ?>"><?php echo $row_meal["Meals_type"] ?></option>

                                            <?php

                                                }
                                            }
                                            ?>
                                        </select>
                                            </div>
                                        </div>     
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">No.of Rooms</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="number" id="input-group" class="form-control input-box form-rounded" name="no_of_rooms" placeholder="" min="0" max="10" required>

                                            </div>
                                        </div>  
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1"> No.of Tents:</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="number" id="input-group" class="form-control input-box form-rounded" name="no_of_tents" placeholder="" min="0" max="10" required>

                                            </div>
                                        </div>  
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Adults</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="number" class="form-control w-100 input-box form-rounded" name="adults" min="1" max="100" required>

                                            </div>
                                        </div>  
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Children</label>
                                            </div>
                                            <div class="col-md-8">
                                            <input type="number" class="form-control w-100 input-box form-rounded" name="children" min="0" max="100" required>

                                            </div>
                                        </div>                 
                                        <div class="form-group pt-4">
                                            <div class="col-md-3">
                                                <label for="exampleInputEmail1">Packege Status</label>
                                            </div>
                                            <div class="col-md-8">
                                                <select class="form-control" name="pack_status">
                                                    <option value="active">Active</option>
                                                    <option value="inactive">Inactive</option>
                                                </select>
                                            </div>
                                        </div>                      
                                        <div class="col-md-12 text-center pt-4">
                                            <button type="submit" id="addbtn"
                                                class="btn btn-primary text-center">Add</button>
                                        </div>

                                    </form>
                                </div>

                            </div>
                            <script>        $(document).ready(function() {

$("form[name='bookingFrm']").validate({

    rules: {
        email: {
            required: true
        },
        contact_number: {
            required: true,
            maxlength: 13,
            minlength: 10,
            digits: true
        }

    },
    messages: {
        email: {
            required: "This field is required"
        },

        contact_number: {
            required: "This field is required",
            maxlength: "Invalid Format Digits",
            minlength: "Number Should be atleast 10 Digits",
            digits: "Only Numbers"
        }

    },

    submitHandler: function(form) {

        $("#savebt").html('Saving ...');
        $("#savebt").prop('disabled', true);


        $.ajax({
            url: "process.php",
            type: "POST",
            data: new FormData(form),
            contentType: false,
            cache: false,
            processData: false,
            beforeSend: function() {

            },
            success: function(data) {
                $("#savebt").html('Save');
                $("#savebt").prop('disabled', false);
                swal("Good job!", "Successfully Updated!", "success");
                window.setTimeout(function() {
                    window.location.href = 'myaccount.php';
                }, 3000);

            },
            error: function() {

            }
        });



    }

});

});
                            </script>


                        </div>
                    </div>
                    <!-- END INPUTS -->
                </div>
            </div>
            <!-- END MAIN CONTENT -->
        </div>
        <!-- END MAIN -->
        <div class="clearfix"></div>
        <!-- FOOTER  -->
        <?php include_once "inc/footer.php" ?>

    </div>
    <!-- END WRAPPER -->
    <!-- Javascript -->
    <?php include_once "inc/scripts.php" ?>
</body>

</html>