<?php
include_once "inc/connection.php";

 $aID = $_GET["aID"];

 // sql to delete a record
 $sql = "DELETE FROM camp_activity WHERE aid=$aID";

if (mysqli_query($conn, $sql)) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . mysqli_error($conn);
}



?>