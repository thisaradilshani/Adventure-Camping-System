<?php
session_start();

if (isset($_SESSION['userID'])) {
    $cust_id = $_SESSION['userID'];
} else {
    header("Location: login-user.php");
}

include 'inc/connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $date = date('Y-m-d H:i:s');    

    $bookID = $_POST['bookID'];
    $check_in_date = $_POST['check_in_date'];
	$check_out_date = $_POST['check_out_date'];
	$cust_id = $_POST['cust_id'];
	$First_name = $_POST['First_name'];
	$Last_name = $_POST['Last_name'];
	$contact_number = $_POST['contact_number'];
	$email = $_POST['email'];
	$package = $_POST['Packages'];
	$Room_type = $_POST['Room_type'];
	$Tent_type = $_POST['Tent_type'];
	$Meals_type = $_POST['Meals_type'];
	$persons = $_POST['no_of_guest'];

    $sql_booking = "SELECT * FROM `booking` WHERE booking_id='$bookID'";
    $result_booking = mysqli_query($conn, $sql_booking);
    $row_booking = mysqli_fetch_assoc($result_booking);

    $no_of_rooms = $row_booking["no_of_rooms"];
    $no_of_tents  = $row_booking["no_of_tents"];

    $sql_package = "SELECT * FROM `packages` WHERE id=$package";
    $result_package = mysqli_query($conn, $sql_package);
    $row_package = mysqli_fetch_assoc($result_package);

    $packagePrice = $row_package["pack_price"];

    $startTimeStamp = strtotime($check_in_date);
	$endTimeStamp = strtotime($check_out_date);

	$timeDiff = abs($endTimeStamp - $startTimeStamp);

	 $numberDays = $timeDiff/86400;  // 86400 seconds in one day

	// and you might want to convert to integer
    $dayCount = intval($numberDays);

    
    $sql_extra = "SELECT * FROM `booking_activity` WHERE `book_id` = '$bookID'";
    $result_extra = mysqli_query($conn, $sql_extra);
    while ($row_extra = mysqli_fetch_assoc($result_extra)) {
        $acID = $row_extra["activity_id"];

        $sql_extra_act = "SELECT * FROM camp_activity WHERE aid= '$acID'";
        $result_extra_act = mysqli_query($conn, $sql_extra_act);

        if (mysqli_num_rows($result_extra_act) > 0) {
            // output data of each row

            while ($row_extra_act = mysqli_fetch_assoc($result_extra_act)) {
             echo  "<br>". $extraActPrice += $row_extra_act['ac_price'];   
            }
        } else {
            echo "0 results";
        }
    }
 

	if(isset($_POST['activitySelect'])){
	echo	$activity_count         = count($_POST['activitySelect']);
		
	}else{
		$activity_count = 0;
	}


	for ($b = 0; $b < $activity_count; $b++) {

		$activity_id = $_POST['activitySelect'][$b];

		$sqlActNAMe = "SELECT * FROM camp_activity WHERE aid='$activity_id'";
		$result_ActNAMe = mysqli_query($conn, $sqlActNAMe);
		$rowActNAMe = mysqli_fetch_assoc($result_ActNAMe);

	    $xtreaActPrice += $rowActNAMe["ac_price"];	

	}

    for ($a = 0; $a < $activity_count; $a++) {

		$activity_id = $_POST['activitySelect'][$a];

		$sql_activity = "INSERT INTO booking_activity (`book_id`, activity_id, date) VALUES ('$bookID', '$activity_id', '$date')";
		$result_activity = mysqli_query($conn, $sql_activity);
	}

		


  $totalPeople = $persons;

	$sql_room = "SELECT * FROM rooms WHERE id='$Room_type'";
	$result_room = mysqli_query($conn, $sql_room);
	$row_room = mysqli_fetch_assoc($result_room);

    $singler_price = $row_room["price"];

	$room_price = ($singler_price * $no_of_rooms) * $dayCount;

	// meals totla

	$sql_meal = "SELECT * FROM `meals` WHERE `id` = '$Meals_type'";
	$result_meal = mysqli_query($conn, $sql_meal);
	$row_meal = mysqli_fetch_assoc($result_meal);

	$singlem_price = $row_meal["price"];
	$meal_price = $singlem_price * $dayCount;

	// tent total
	$sql_tent = "SELECT * FROM `tent` WHERE `id` = '$Tent_type'";
	$result_tent = mysqli_query($conn, $sql_tent);
	$row_tent = mysqli_fetch_assoc($result_tent);

	$singlet_price = $row_tent["price"];
	$tent_price = ($singlet_price * $no_of_tents) * $dayCount;

	// echo $packagePrice."<br>";
	// echo $meal_price."<br>";
	// echo $xtreaActPrice."<br>";
	// echo $totalPeople."<br>";
	// echo $room_price."<br>";
	// echo $tent_price."<br>";

	$total = ($packagePrice + $meal_price + $extraActPrice) * $totalPeople + $room_price + $tent_price;



    $sql = "UPDATE booking SET 

    booking_id ='$bookID', 
    check_in_date='$check_in_date', 
    check_out_date='$check_out_date', 
    customer_id='$cust_id', 
    first_name='$First_name', 
    last_name='$Last_name', 
    contact_number='$contact_number', 
    email='$email', 
    pack_id='$package', 
    room_type='$Room_type', 
    tent_type='$Tent_type', 
    meals_type='$Meals_type', 
    no_of_people='$persons',
    update_date='$date',
    due_amount = '$total'
    
    WHERE booking_id ='$bookID'";

    if (mysqli_query($conn, $sql)) {
        echo "sucess";
    } else {
        echo "error" . mysqli_error($conn);
    }
}
