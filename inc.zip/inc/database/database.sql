-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2021 at 01:49 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'active',
  `role` varchar(255) DEFAULT NULL,
  `userImg` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`userid`, `username`, `password`, `firstname`, `lastname`, `email`, `status`, `role`, `userImg`) VALUES
(1, 'admin', 'admin123', 'Olympia', 'Olympix', 'olympia@gmail.com', 'active', 'admin', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `all_rooms`
--

CREATE TABLE `all_rooms` (
  `room_no` int(2) NOT NULL,
  `Room_type` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_rooms`
--

INSERT INTO `all_rooms` (`room_no`, `Room_type`) VALUES
(1, 'Single Room Non AC'),
(2, 'Single Room Non AC'),
(3, 'Single Room Non AC'),
(4, 'Single Room Non AC'),
(5, 'Single Room Non AC'),
(6, 'Single Room Non AC'),
(7, 'Single Room Non AC'),
(8, 'Single Room Non AC'),
(9, 'Single Room AC'),
(10, 'Single Room AC'),
(11, 'Single Room AC'),
(12, 'Single Room AC'),
(13, 'Single Room AC'),
(14, 'Double Room Non AC'),
(15, 'Double Room Non AC'),
(16, 'Double Room Non AC'),
(17, 'Double Room Non AC'),
(18, 'Double Room Non AC'),
(19, 'Double Room Non AC'),
(20, 'Double Room Non AC'),
(21, 'Double Room AC'),
(22, 'Double Room AC'),
(23, 'Double Room AC'),
(24, 'Double Room AC'),
(25, 'Four Person Room Non AC'),
(26, 'Four Person Room Non AC'),
(27, 'Four Person Room Non AC'),
(28, 'Four Person Room Non AC'),
(29, 'Four Person Room Non AC'),
(30, 'Four Person Room Non AC'),
(31, 'Four Person Room AC'),
(32, 'Four Person Room AC'),
(33, 'Four Person Room AC'),
(34, 'Ten Person Room Non AC'),
(35, 'Ten Person Room Non AC'),
(36, 'Twenty Person Hall Non AC');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `pack_id` int(11) DEFAULT NULL,
  `paid_status` varchar(255) DEFAULT NULL,
  `due_amount` varchar(40) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `no_of_rooms` varchar(50) DEFAULT NULL,
  `no_of_tents` varchar(50) DEFAULT NULL,
  `no_of_people` varchar(255) DEFAULT NULL,
  `adults` varchar(255) DEFAULT NULL,
  `childern` varchar(255) DEFAULT NULL,
  `room_type` varchar(50) DEFAULT NULL,
  `tent_type` varchar(50) DEFAULT NULL,
  `meals_type` varchar(50) DEFAULT NULL,
  `check_in_date` date DEFAULT NULL,
  `check_out_date` date DEFAULT NULL,
  `add_date` date DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `customer_id`, `pack_id`, `paid_status`, `due_amount`, `first_name`, `last_name`, `contact_number`, `email`, `no_of_rooms`, `no_of_tents`, `no_of_people`, `adults`, `childern`, `room_type`, `tent_type`, `meals_type`, `check_in_date`, `check_out_date`, `add_date`, `update_date`, `status`) VALUES
(3, 3, 1004, 'paid', '400', 'seha', 'seha', '0094767963987', 'sehanichathurangi21@gmail.com', '1', '0', '1', '1', '0', '1', '6', '1', '2021-07-27', '2021-07-28', '2021-07-25', NULL, 'active'),
(5, 3, 1004, 'unpaid', '658.5', 'thisara', 'Dilshani', '0094768951235', 'sehanichathurangi21@gmail.com', '1', '1', '2', '1', '1', '1', '1', '1', '2021-07-27', '2021-07-29', '2021-07-25', NULL, 'active'),
(9, 5, 1001, 'paid', '434', 'saduni', 'Karunarathne', '0094718951235', 'dvcjdkw@gmail.com', '1', '1', '2', '1', '1', '1', '6', '7', '2021-08-27', '2021-08-28', '2021-08-22', NULL, 'active'),
(10, 13, 1004, 'paid', '1246', 'Sandeepa', 'Perera', '0094712359684', 'iit18049@std.uwu.ac.lk', '1', '1', '4', '4', '0', '3', '4', '1', '2021-08-27', '2021-08-30', '2021-08-22', NULL, 'active'),
(11, 5, 1003, 'paid', '254', 'Dinithi', 'Wattage', '0094705869234', 'dinithikavishna@gmail.com', '1', '0', '1', '1', '0', '1', '6', '1', '2021-09-08', '2021-09-10', '2021-08-22', NULL, 'active'),
(12, 11, 1000, 'unpaid', '480', 'Ishanka', 'punchihewa', '0094752359564', 'ishankasandeepa6@gmail.com', '1', '0', '2', '2', '0', '1', '6', '1', '2021-09-01', '2021-09-02', '2021-08-22', NULL, 'active'),
(13, 7, 1008, 'unpaid', '1860', 'Lakshika', 'Balasinghe', '0094768596324', 'iit18016@std.uwu.ac.lk', '0', '0', '12', '12', '0', '9', '6', '2', '2021-08-30', '2021-08-30', '2021-08-22', NULL, 'active'),
(14, 12, 1007, 'paid', '70', 'Chathurangi', 'Sehasna', '0094718955963', 'iit18034@std.uwu.ac.lk', '0', '1', '1', '1', '0', '9', '2', '3', '2021-09-10', '2021-09-11', '2021-08-22', NULL, 'active'),
(15, 9, 1005, 'unpaid', '310', 'Kavindi', 'gamage', '0094718694523', 'kavindinavodyaknu@gmail.com', '1', '0', '2', '2', '0', '3', '6', '1', '2021-08-25', '2021-08-26', '2021-08-22', NULL, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `booking_activity`
--

CREATE TABLE `booking_activity` (
  `id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking_activity`
--

INSERT INTO `booking_activity` (`id`, `book_id`, `activity_id`, `date`) VALUES
(1, 1, 3, '2021-07-24 14:04:43'),
(2, 3, 2, '2021-07-25 13:06:27'),
(3, 4, 5, '2021-07-25 13:21:04'),
(4, 5, 3, '2021-07-25 15:42:21'),
(5, 6, 2, '2021-07-25 15:50:14'),
(6, 7, 3, '2021-08-21 12:43:31'),
(7, 8, 4, '2021-08-21 12:48:48'),
(8, 11, 3, '2021-08-22 17:02:50');

-- --------------------------------------------------------

--
-- Table structure for table `camp_activity`
--

CREATE TABLE `camp_activity` (
  `aid` int(11) NOT NULL,
  `ac_name` varchar(255) DEFAULT NULL,
  `ac_price` varchar(255) DEFAULT NULL,
  `ac_status` varchar(255) DEFAULT NULL,
  `ac_desc` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `camp_activity`
--

INSERT INTO `camp_activity` (`aid`, `ac_name`, `ac_price`, `ac_status`, `ac_desc`, `date_created`) VALUES
(1, 'White Water Rafting', '150', 'active', 'Rafting and whitewater rafting are recreational outdoor activities which use an inflatable raft to navigate a river or other body of water. This is often done on whitewater or different degrees of rough water. Dealing with risk is often a part of the expe', '2021-07-02 08:48:16'),
(2, 'Waterfall trekking', '50', 'active', NULL, '2021-07-02 08:27:06'),
(3, 'Flat water rafting', '24', 'active', 'ewerwe ', '2021-07-02 08:00:24'),
(4, 'River expeditions', '55', 'active', '', '2021-07-02 08:00:52'),
(5, 'Waterfall abseiling', '75', 'active', '', '2021-07-02 08:02:16'),
(6, 'Boat Safari', '30', 'active', '', '2021-07-02 08:02:34'),
(7, 'Hot air baloon', '125', 'active', '', '2021-07-02 08:02:45'),
(8, 'Zip lining', '32', 'active', '', '2021-07-02 08:02:55'),
(9, 'Paragliding', '100', 'active', '', '2021-07-02 08:03:07'),
(10, 'Hiking', '45', 'active', '', '2021-07-02 08:03:18'),
(11, 'Forest trekking', '50', 'active', '', '2021-07-02 08:03:28'),
(12, 'Cycling', '50', 'active', '', '2021-07-02 08:03:44'),
(13, 'Bird watching', '20', 'active', '', '2021-07-02 08:03:53'),
(14, 'Archery', '15', 'active', '', '2021-07-02 08:04:10'),
(15, 'Safari', '42', 'active', '', '2021-07-02 08:04:22'),
(16, 'Night Camping', '30', 'active', 'Nigth Capmign for 10 person ', '2021-07-02 12:15:20'),
(17, 'Accommodation Only', '0', 'active', '', '2021-08-22 10:57:49');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(300) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` varchar(8) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact_no` int(10) NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `Gender` varchar(7) NOT NULL,
  `Age` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `meals`
--

CREATE TABLE `meals` (
  `id` int(11) NOT NULL,
  `Meals_type` varchar(50) NOT NULL,
  `price` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meals`
--

INSERT INTO `meals` (`id`, `Meals_type`, `price`) VALUES
(1, 'Breakfast ', '2.50'),
(2, 'Lunch ', '3.00'),
(3, 'Dinner', '3.50'),
(4, 'None', '0.00'),
(5, 'Breakfast + Lunch', '5.50'),
(6, 'Lunch + Dinner', '6.50'),
(7, 'Breakfast + Dinner', '6.00'),
(8, 'Breakfast + Lunch + Dinner', '9.00');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `pack_name` varchar(255) DEFAULT NULL,
  `pack_type` varchar(255) DEFAULT NULL,
  `pack_price` varchar(255) DEFAULT NULL,
  `pack_details` varchar(255) DEFAULT NULL,
  `pack_status` varchar(255) DEFAULT NULL,
  `pack_img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `pack_name`, `pack_type`, `pack_price`, `pack_details`, `pack_status`, `pack_img`) VALUES
(1000, 'Package A', 'per person', '200', 'Pick this holiday for a relaxing vacation in Paris and Switzerland. Your tour embarks from Paris. Enjoy an excursion to popular attractions like the iconic Eiffel Tower. After experiencing the beautiful city, you will drive past mustard fields through Bur', 'active', 'userImage/1_1.jpg'),
(1001, 'Package B', 'per person', '142', 'The two-wire zip-line stretches for more than half a kilometer, slides at 80kmph and offers a bird’s-eye view of the beautiful hills of the island.\r\nGet on board at Mini Adam’s Peak and fly over iconic tea estates and lush greenery overlooking the famous ', 'active', 'userImage/8.jpg'),
(1002, 'Package C', 'per person', '167', 'Create unique adventures from Olympia. Each package has a different activities and you can choose various accommodation types. If you stay for one night you would be able to do many adventure and leisure activities.', 'active', 'userImage/9.jpg'),
(1003, 'Package D', 'per person', '166', 'Create unique adventures from Olympia. Each package has a different activities and you can choose various accommodation types. If you stay for one night you would be able to do many adventure and leisure activities.', 'active', 'userImage/a.jpg'),
(1004, 'Package E', 'per person', '260', 'Create unique adventures from Olympia. Each package has a different activities and you can choose various accommodation types. If you stay for one night you would be able to do many adventure and leisure activities.', 'active', 'userImage/9.jpg'),
(1005, 'Package F', 'per person', '110', 'Create unique adventures from Olympia. Each package has a different activities and you can choose various accommodation types. If you stay for one night you would be able to do many adventure and leisure activities.', 'active', 'userImage/11_1.jpg'),
(1007, 'Package G', 'Per Person', '30', '', 'active', 'userImage/night-camping-and-surfing-at-elephant-rock-11.jpg'),
(1008, 'Package H', 'Per Person', '125', '', 'active', 'userImage/7.jpg'),
(1009, 'Package I', 'Per Person', '0', '', 'active', 'userImage/room3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `packages_activity_list`
--

CREATE TABLE `packages_activity_list` (
  `id` int(11) NOT NULL,
  `package_id` int(11) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `addby` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `packages_activity_list`
--

INSERT INTO `packages_activity_list` (`id`, `package_id`, `activity_id`, `date`, `addby`) VALUES
(1, 1000, 1, '2021-07-02 12:17:40', '1'),
(2, 1000, 7, '2021-07-02 12:17:40', '1'),
(3, 1000, 10, '2021-07-02 12:17:40', '1'),
(4, 1000, 16, '2021-07-02 12:17:40', '1'),
(5, 1001, 2, '2021-07-02 18:10:20', '1'),
(6, 1001, 8, '2021-07-02 18:10:20', '1'),
(7, 1001, 14, '2021-07-02 18:10:20', '1'),
(8, 1001, 15, '2021-07-02 18:10:20', '1'),
(9, 1002, 3, '2021-07-10 14:00:02', '2'),
(10, 1002, 9, '2021-07-10 14:00:02', '2'),
(11, 1002, 12, '2021-07-10 14:00:02', '2'),
(12, 1003, 4, '2021-07-10 14:04:12', '2'),
(13, 1003, 5, '2021-07-10 14:04:12', '2'),
(14, 1003, 6, '2021-07-10 14:04:12', '2'),
(15, 1004, 7, '2021-07-10 14:06:27', '2'),
(16, 1004, 8, '2021-07-10 14:06:27', '2'),
(17, 1004, 9, '2021-07-10 14:06:27', '2'),
(18, 1005, 11, '2021-07-10 14:08:05', '2'),
(19, 1005, 12, '2021-07-10 14:08:05', '2'),
(20, 1005, 14, '2021-07-10 14:08:05', '2'),
(21, 1007, 16, '2021-08-22 10:52:21', '5'),
(22, 1008, 7, '2021-08-22 10:54:28', '5'),
(23, 1009, 17, '2021-08-22 10:59:10', '5');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `pay_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `total` varchar(55) DEFAULT NULL,
  `status` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`pay_id`, `customer_id`, `booking_id`, `date`, `payment_date`, `total`, `status`) VALUES
(1, 1, 1, '2021-07-08 04:56:46', '2021-07-24 14:08:00', '348', 'paid'),
(2, 1, 2, '2021-07-08 05:31:03', '2021-07-24 14:16:01', '561', 'paid'),
(3, 1, 3, '2021-07-08 05:32:10', '2021-07-25 13:15:57', '400', 'paid'),
(4, 1, 4, '2021-07-08 05:33:38', NULL, '1984', 'unpaid'),
(5, 1, 5, '2021-07-08 05:34:19', NULL, '1984', 'unpaid'),
(6, 1, 6, '2021-07-08 05:35:36', NULL, '830', 'unpaid'),
(7, 1, 7, '2021-07-08 05:37:27', '2021-08-21 12:54:02', '1047', 'paid'),
(8, 1, 8, '2021-07-08 05:39:24', '2021-08-21 12:52:17', '1135', 'paid'),
(9, 1, 9, '2021-07-08 05:42:08', '2021-08-22 16:58:52', '434', 'paid'),
(10, 2, 10, '2021-07-10 19:57:38', '2021-08-22 16:56:57', '1246', 'paid'),
(11, 1, 11, '2021-07-11 21:43:32', '2021-08-22 17:03:57', '254', 'paid'),
(12, 1, 12, '2021-07-11 21:45:14', NULL, '374.5', 'unpaid'),
(13, 1, 13, '2021-07-11 21:46:28', NULL, '187.25', 'unpaid'),
(14, 1, 14, '2021-07-11 21:48:35', '2021-08-22 17:15:36', '70', 'paid'),
(15, 3, 1, '2021-07-24 14:04:43', '2021-07-24 14:08:00', '348', 'paid'),
(16, 3, 2, '2021-07-24 14:15:16', '2021-07-24 14:16:01', '561', 'paid'),
(17, 3, 3, '2021-07-25 13:06:27', '2021-07-25 13:15:57', '400', 'paid'),
(18, 3, 4, '2021-07-25 13:21:04', NULL, '257', 'unpaid'),
(19, 3, 5, '2021-07-25 15:42:21', NULL, '658.5', 'unpaid'),
(20, 3, 6, '2021-07-25 15:50:14', NULL, '710.5', 'unpaid'),
(21, 3, 7, '2021-08-21 12:43:31', '2021-08-21 12:54:02', '1047', 'paid'),
(22, 3, 8, '2021-08-21 12:48:48', '2021-08-21 12:52:17', '1135', 'paid'),
(23, 5, 9, '2021-08-22 16:18:38', '2021-08-22 16:58:52', '434', 'paid'),
(24, 13, 10, '2021-08-22 16:55:12', '2021-08-22 16:56:57', '1246', 'paid'),
(25, 5, 11, '2021-08-22 17:02:50', '2021-08-22 17:03:57', '254', 'paid'),
(26, 11, 12, '2021-08-22 17:08:01', NULL, '480', 'unpaid'),
(27, 7, 13, '2021-08-22 17:11:41', NULL, '1860', 'unpaid'),
(28, 12, 14, '2021-08-22 17:14:25', '2021-08-22 17:15:36', '70', 'paid'),
(29, 9, 15, '2021-08-22 17:17:47', NULL, '310', 'unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `receiptionist`
--

CREATE TABLE `receiptionist` (
  `Recep_id` varchar(8) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Contact_no` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `total_rooms` int(2) DEFAULT NULL,
  `Room_type` varchar(50) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `max_guest` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `total_rooms`, `Room_type`, `price`, `max_guest`) VALUES
(1, 8, 'Single Room Non AC', '15.00', 1),
(2, 5, 'Single Room AC', '25.00', 1),
(3, 7, 'Double Room Non AC', '20.00', 2),
(4, 4, 'Double Room AC', '35.00', 2),
(5, 6, 'Four Person Room Non AC', '30.00', 4),
(6, 3, 'Four Person Room AC', '40.00', 4),
(7, 2, 'Ten Person Hall Non AC', '60.00', 10),
(8, 1, 'Twenty Person Hall Non AC', '100.00', 20),
(9, 0, 'None', '0.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tent`
--

CREATE TABLE `tent` (
  `id` int(11) NOT NULL,
  `Tent_type` varchar(10) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `max_guest` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tent`
--

INSERT INTO `tent` (`id`, `Tent_type`, `price`, `max_guest`) VALUES
(1, 'XS Tent', '5.25', 1),
(2, 'S tent', '5.50', 2),
(3, 'M tent', '5.75', 4),
(4, 'L tent', '6.50', 6),
(5, 'XL tent', '7.25', 8),
(6, 'None', '0.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `code` mediumint(50) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `email`, `password`, `code`, `status`) VALUES
(2, 'Thisara', 'thisaradilshani821@gmail.com', '$2y$10$hsLFEvtTXK3xliYr1QYvXOlrDelCk2Ac7bI5EZ.KaPl3r4K6CZcEK', 0, 'verified'),
(3, 'seha', 'sehanichathurangi21@gmail.com', '$2y$10$S3qClETMNYUA4Pgll8vmleOqqSYZJpZRd7j6robh1GLdOu6NUnbPi', 0, 'verified'),
(5, 'Dinithi Wattage', 'dinithikavishna@gmail.com', '$2y$10$4UUw.lVBWU59nrpZS24ri.P7C0/k7zOqfRTVkG0uhksWni.KevyjG', 0, 'verified'),
(6, 'Sadali Karunarathne', 'dvcjdkw@gmail.com', '$2y$10$8d6WLRfXe8/PfA6GhbIb2.3FDQcwrpaAObe.Yb4UAdAox1yYzshVi', 0, 'verified'),
(7, 'Lakshika Balasinghe', 'iit18016@std.uwu.ac.lk', '$2y$10$bF4.JICgUp5qld7IOyITt./iJoy/7hx2z5TQsbCizY6JPg9TwhASS', 0, 'verified'),
(8, 'Wasana Fonseka', 'wasanafonseka61@gmail.com', '$2y$10$AOwoeZ.GYCVwVoupWTf.q.u8prqEyfPipB1Lfl4XnMvLYTT8f1bJ6', 0, 'verified'),
(9, 'Kavindi Gamage', 'kavindinavodyaknu@gmail.com', '$2y$10$lFH8lUUv64be5ue0SPXA1eL0rM5r0CdZyKhoINQ.sn8PdarHaKzxy', 0, 'verified'),
(10, 'Jayathissa Gamage', 'jayatissag@gmail.com', '$2y$10$p2xTfYtuBwBUYkKJlEL5uOATl5/hsD0x2LaJte.chUPwAVHbodEQC', 0, 'verified'),
(11, 'Ishanka Punchihewa', 'ishankasandeepa6@gmail.com', '$2y$10$rK4kWc6Ucv3AjD4XFKwJAuCKhEOqcw1qjgfwJ5EfjIk7lHRaVf8F2', 0, 'verified'),
(12, 'Chathurangi sehasna', 'iit18034@std.uwu.ac.lk', '$2y$10$sS9Vnsb5XF43b1PghsY1Uuh0gv9ITl91dHfXC6eK0YA9x/EHN.L4m', 0, 'verified'),
(13, 'Sandeepa Perera', 'iit18049@std.uwu.ac.lk', '$2y$10$alQ2GYYv34y3d64AdEQnleNfuwE9xyeDQf5uG0jMuzg7ZekbDnIPO', 0, 'verified');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `all_rooms`
--
ALTER TABLE `all_rooms`
  ADD PRIMARY KEY (`room_no`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `booking_activity`
--
ALTER TABLE `booking_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `camp_activity`
--
ALTER TABLE `camp_activity`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `meals`
--
ALTER TABLE `meals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages_activity_list`
--
ALTER TABLE `packages_activity_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `receiptionist`
--
ALTER TABLE `receiptionist`
  ADD PRIMARY KEY (`Recep_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tent`
--
ALTER TABLE `tent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `all_rooms`
--
ALTER TABLE `all_rooms`
  MODIFY `room_no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `booking_activity`
--
ALTER TABLE `booking_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `camp_activity`
--
ALTER TABLE `camp_activity`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `meals`
--
ALTER TABLE `meals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1010;

--
-- AUTO_INCREMENT for table `packages_activity_list`
--
ALTER TABLE `packages_activity_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tent`
--
ALTER TABLE `tent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
