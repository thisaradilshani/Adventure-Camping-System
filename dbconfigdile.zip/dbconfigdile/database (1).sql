-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2021 at 09:06 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `userid` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT 'active',
  `role` varchar(255) DEFAULT NULL,
  `userImg` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`userid`, `username`, `password`, `firstname`, `lastname`, `email`, `status`, `role`, `userImg`) VALUES
(1, 'admin', 'admin123', 'Olympia', 'Olympix', 'olympia@gmail.com', 'active', 'admin', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `all_rooms`
--

CREATE TABLE `all_rooms` (
  `room_no` int(2) NOT NULL,
  `Room_type` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_rooms`
--

INSERT INTO `all_rooms` (`room_no`, `Room_type`) VALUES
(1, 'Single Room Non AC'),
(2, 'Single Room Non AC'),
(3, 'Single Room Non AC'),
(4, 'Single Room Non AC'),
(5, 'Single Room Non AC'),
(6, 'Single Room Non AC'),
(7, 'Single Room Non AC'),
(8, 'Single Room Non AC'),
(9, 'Single Room AC'),
(10, 'Single Room AC'),
(11, 'Single Room AC'),
(12, 'Single Room AC'),
(13, 'Single Room AC'),
(14, 'Double Room Non AC'),
(15, 'Double Room Non AC'),
(16, 'Double Room Non AC'),
(17, 'Double Room Non AC'),
(18, 'Double Room Non AC'),
(19, 'Double Room Non AC'),
(20, 'Double Room Non AC'),
(21, 'Double Room AC'),
(22, 'Double Room AC'),
(23, 'Double Room AC'),
(24, 'Double Room AC'),
(25, 'Four Person Room Non AC'),
(26, 'Four Person Room Non AC'),
(27, 'Four Person Room Non AC'),
(28, 'Four Person Room Non AC'),
(29, 'Four Person Room Non AC'),
(30, 'Four Person Room Non AC'),
(31, 'Four Person Room AC'),
(32, 'Four Person Room AC'),
(33, 'Four Person Room AC'),
(34, 'Ten Person Room Non AC'),
(35, 'Ten Person Room Non AC'),
(36, 'Twenty Person Hall Non AC');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `pack_id` int(11) DEFAULT NULL,
  `paid_status` varchar(255) DEFAULT NULL,
  `due_amount` varchar(40) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `no_of_rooms` varchar(50) DEFAULT NULL,
  `no_of_tents` varchar(50) DEFAULT NULL,
  `no_of_people` varchar(255) DEFAULT NULL,
  `adults` varchar(255) DEFAULT NULL,
  `childern` varchar(255) DEFAULT NULL,
  `room_type` varchar(50) DEFAULT NULL,
  `tent_type` varchar(50) DEFAULT NULL,
  `meals_type` varchar(50) DEFAULT NULL,
  `check_in_date` date DEFAULT NULL,
  `check_out_date` date DEFAULT NULL,
  `add_date` date DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `booking_activity`
--

CREATE TABLE `booking_activity` (
  `id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `camp_activity`
--

CREATE TABLE `camp_activity` (
  `aid` int(11) NOT NULL,
  `ac_name` varchar(255) DEFAULT NULL,
  `ac_price` varchar(255) DEFAULT NULL,
  `ac_status` varchar(255) DEFAULT NULL,
  `ac_desc` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `camp_activity`
--

INSERT INTO `camp_activity` (`aid`, `ac_name`, `ac_price`, `ac_status`, `ac_desc`, `date_created`) VALUES
(1, 'White Water Rafting', '150', 'active', 'Rafting and whitewater rafting are recreational outdoor activities which use an inflatable raft to navigate a river or other body of water. This is often done on whitewater or different degrees of rough water. Dealing with risk is often a part of the expe', '2021-07-02 08:48:16'),
(2, 'Waterfall trekking', '50', 'active', NULL, '2021-07-02 08:27:06'),
(3, 'Flat water rafting', '24', 'active', 'ewerwe ', '2021-07-02 08:00:24'),
(4, 'River expeditions', '55', 'active', '', '2021-07-02 08:00:52'),
(5, 'Waterfall abseiling', '75', 'active', '', '2021-07-02 08:02:16'),
(6, 'Boat Safari', '30', 'active', '', '2021-07-02 08:02:34'),
(7, 'Hot air baloon', '125', 'active', '', '2021-07-02 08:02:45'),
(8, 'Zip lining', '32', 'active', '', '2021-07-02 08:02:55'),
(9, 'Paragliding', '100', 'active', '', '2021-07-02 08:03:07'),
(10, 'Hiking', '45', 'active', '', '2021-07-02 08:03:18'),
(11, 'Forest trekking', '50', 'active', '', '2021-07-02 08:03:28'),
(12, 'Cycling', '50', 'active', '', '2021-07-02 08:03:44'),
(13, 'Bird watching', '20', 'active', '', '2021-07-02 08:03:53'),
(14, 'Archery', '15', 'active', '', '2021-07-02 08:04:10'),
(15, 'Safari', '42', 'active', '', '2021-07-02 08:04:22'),
(16, 'Night Camping', '30', 'active', 'Nigth Capmign for 10 person ', '2021-07-02 12:15:20');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(300) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` varchar(8) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact_no` int(10) NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `Gender` varchar(7) NOT NULL,
  `Age` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `meals`
--

CREATE TABLE `meals` (
  `id` int(11) NOT NULL,
  `Meals_type` varchar(50) NOT NULL,
  `price` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meals`
--

INSERT INTO `meals` (`id`, `Meals_type`, `price`) VALUES
(1, 'Breakfast ', '2.50'),
(2, 'Lunch ', '3.00'),
(3, 'Dinner', '3.50'),
(4, 'None', '0.00'),
(5, 'Breakfast + Lunch', '5.50'),
(6, 'Lunch + Dinner', '6.50'),
(7, 'Breakfast + Dinner', '6.00'),
(8, 'Breakfast + Lunch + Dinner', '9.00');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `pack_name` varchar(255) DEFAULT NULL,
  `pack_type` varchar(255) DEFAULT NULL,
  `pack_price` varchar(255) DEFAULT NULL,
  `pack_details` varchar(255) DEFAULT NULL,
  `pack_status` varchar(255) DEFAULT NULL,
  `pack_img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `pack_name`, `pack_type`, `pack_price`, `pack_details`, `pack_status`, `pack_img`) VALUES
(1001, 'Package B', 'per person', '142', 'The two-wire zip-line stretches for more than half a kilometer, slides at 80kmph and offers a bird’s-eye view of the beautiful hills of the island.\r\nGet on board at Mini Adam’s Peak and fly over iconic tea estates and lush greenery overlooking the famous ', 'active', 'userImage/8.jpg'),
(1002, 'Package C', 'per person', '167', 'Create unique adventures from Olympia. Each package has a different activities and you can choose various accommodation types. If you stay for one night you would be able to do many adventure and leisure activities.', 'active', 'userImage/9.jpg'),
(1003, 'Package D', 'per person', '166', 'Create unique adventures from Olympia. Each package has a different activities and you can choose various accommodation types. If you stay for one night you would be able to do many adventure and leisure activities.', 'active', 'userImage/a.jpg'),
(1004, 'Package E', 'per person', '260', 'Create unique adventures from Olympia. Each package has a different activities and you can choose various accommodation types. If you stay for one night you would be able to do many adventure and leisure activities.', 'active', 'userImage/9.jpg'),
(1005, 'Package F', 'per person', '110', 'Create unique adventures from Olympia. Each package has a different activities and you can choose various accommodation types. If you stay for one night you would be able to do many adventure and leisure activities.', 'active', 'userImage/11_1.jpg'),
(1007, 'Package G', 'Per Person', '30', '', 'active', 'userImage/night-camping-and-surfing-at-elephant-rock-11.jpg'),
(1008, 'Package H', 'Per Person', '125', '', 'active', 'userImage/7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `packages_activity_list`
--

CREATE TABLE `packages_activity_list` (
  `id` int(11) NOT NULL,
  `package_id` int(11) DEFAULT NULL,
  `activity_id` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `addby` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `packages_activity_list`
--

INSERT INTO `packages_activity_list` (`id`, `package_id`, `activity_id`, `date`, `addby`) VALUES
(2, 1000, 7, '2021-07-02 12:17:40', '1'),
(3, 1000, 10, '2021-07-02 12:17:40', '1'),
(4, 1000, 16, '2021-07-02 12:17:40', '1'),
(5, 1001, 2, '2021-07-02 18:10:20', '1'),
(6, 1001, 8, '2021-07-02 18:10:20', '1'),
(7, 1001, 14, '2021-07-02 18:10:20', '1'),
(8, 1001, 15, '2021-07-02 18:10:20', '1'),
(9, 1002, 3, '2021-07-10 14:00:02', '2'),
(10, 1002, 9, '2021-07-10 14:00:02', '2'),
(11, 1002, 12, '2021-07-10 14:00:02', '2'),
(12, 1003, 4, '2021-07-10 14:04:12', '2'),
(13, 1003, 5, '2021-07-10 14:04:12', '2'),
(14, 1003, 6, '2021-07-10 14:04:12', '2'),
(15, 1004, 7, '2021-07-10 14:06:27', '2'),
(18, 1005, 11, '2021-07-10 14:08:05', '2'),
(19, 1005, 12, '2021-07-10 14:08:05', '2'),
(20, 1005, 14, '2021-07-10 14:08:05', '2'),
(21, 1007, 16, '2021-08-22 10:52:21', '5'),
(22, 1008, 7, '2021-08-22 10:54:28', '5'),
(23, 1009, 17, '2021-08-22 10:59:10', '5');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `pay_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `total` varchar(55) DEFAULT NULL,
  `status` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `receiptionist`
--

CREATE TABLE `receiptionist` (
  `Recep_id` varchar(8) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Contact_no` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `total_rooms` int(2) DEFAULT NULL,
  `Room_type` varchar(50) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `max_guest` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `total_rooms`, `Room_type`, `price`, `max_guest`) VALUES
(1, 8, 'Single Room Non AC', '15.00', 1),
(2, 5, 'Single Room AC', '25.00', 1),
(3, 7, 'Double Room Non AC', '20.00', 2),
(4, 4, 'Double Room AC', '35.00', 2),
(5, 6, 'Four Person Room Non AC', '30.00', 4),
(6, 3, 'Four Person Room AC', '40.00', 4),
(7, 2, 'Ten Person Hall Non AC', '60.00', 10),
(8, 1, 'Twenty Person Hall Non AC', '100.00', 20),
(9, 0, 'None', '0.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tent`
--

CREATE TABLE `tent` (
  `id` int(11) NOT NULL,
  `Tent_type` varchar(10) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `max_guest` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tent`
--

INSERT INTO `tent` (`id`, `Tent_type`, `price`, `max_guest`) VALUES
(1, 'XS Tent', '5.25', 1),
(2, 'S tent', '5.50', 2),
(3, 'M tent', '5.75', 4),
(4, 'L tent', '6.50', 6),
(5, 'XL tent', '7.25', 8),
(6, 'None', '0.00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `code` mediumint(50) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `email`, `password`, `code`, `status`) VALUES
(2, 'Thisara', 'thisaradilshani821@gmail.com', '$2y$10$hsLFEvtTXK3xliYr1QYvXOlrDelCk2Ac7bI5EZ.KaPl3r4K6CZcEK', 0, 'verified'),
(3, 'seha', 'sehanichathurangi21@gmail.com', '$2y$10$S3qClETMNYUA4Pgll8vmleOqqSYZJpZRd7j6robh1GLdOu6NUnbPi', 0, 'verified'),
(5, 'Dinithi Wattage', 'dinithikavishna@gmail.com', '$2y$10$4UUw.lVBWU59nrpZS24ri.P7C0/k7zOqfRTVkG0uhksWni.KevyjG', 0, 'verified'),
(6, 'Sadali Karunarathne', 'dvcjdkw@gmail.com', '$2y$10$8d6WLRfXe8/PfA6GhbIb2.3FDQcwrpaAObe.Yb4UAdAox1yYzshVi', 0, 'verified'),
(7, 'Lakshika Balasinghe', 'iit18016@std.uwu.ac.lk', '$2y$10$bF4.JICgUp5qld7IOyITt./iJoy/7hx2z5TQsbCizY6JPg9TwhASS', 0, 'verified'),
(8, 'Wasana Fonseka', 'wasanafonseka61@gmail.com', '$2y$10$AOwoeZ.GYCVwVoupWTf.q.u8prqEyfPipB1Lfl4XnMvLYTT8f1bJ6', 0, 'verified'),
(9, 'Kavindi Gamage', 'kavindinavodyaknu@gmail.com', '$2y$10$lFH8lUUv64be5ue0SPXA1eL0rM5r0CdZyKhoINQ.sn8PdarHaKzxy', 0, 'verified'),
(10, 'Jayathissa Gamage', 'jayatissag@gmail.com', '$2y$10$p2xTfYtuBwBUYkKJlEL5uOATl5/hsD0x2LaJte.chUPwAVHbodEQC', 0, 'verified'),
(11, 'Ishanka Punchihewa', 'ishankasandeepa6@gmail.com', '$2y$10$rK4kWc6Ucv3AjD4XFKwJAuCKhEOqcw1qjgfwJ5EfjIk7lHRaVf8F2', 0, 'verified');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `all_rooms`
--
ALTER TABLE `all_rooms`
  ADD PRIMARY KEY (`room_no`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `booking_activity`
--
ALTER TABLE `booking_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `camp_activity`
--
ALTER TABLE `camp_activity`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `meals`
--
ALTER TABLE `meals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages_activity_list`
--
ALTER TABLE `packages_activity_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `receiptionist`
--
ALTER TABLE `receiptionist`
  ADD PRIMARY KEY (`Recep_id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tent`
--
ALTER TABLE `tent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `all_rooms`
--
ALTER TABLE `all_rooms`
  MODIFY `room_no` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `booking_activity`
--
ALTER TABLE `booking_activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `camp_activity`
--
ALTER TABLE `camp_activity`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `meals`
--
ALTER TABLE `meals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1010;

--
-- AUTO_INCREMENT for table `packages_activity_list`
--
ALTER TABLE `packages_activity_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tent`
--
ALTER TABLE `tent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
